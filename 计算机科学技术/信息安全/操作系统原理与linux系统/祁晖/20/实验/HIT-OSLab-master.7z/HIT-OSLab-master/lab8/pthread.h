#ifndef PTHREAD_H
#define PTHREAD_H


#define STACK_SIZE 1024

typedef int (*fn_ptr)(int);
typedef int pthread_t;

#endif